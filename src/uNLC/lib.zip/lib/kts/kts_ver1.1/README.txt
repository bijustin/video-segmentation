Kernel temporal segmentation
============================

This archive contains the following files:
cpd_nonlin.py   -   kernel temporal segmentation with fixed number of segments
cpd_auto.py     -   kernel temporal segmentation with autocalibration
demo.py         -   demo on synthetic examples

Dependencies:
python + libraries: numpy, scipy, matplotlib (for demo)
